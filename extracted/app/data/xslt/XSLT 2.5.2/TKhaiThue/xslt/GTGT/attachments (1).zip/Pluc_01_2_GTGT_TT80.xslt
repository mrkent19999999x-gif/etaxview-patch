<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihtkk="http://www.nhantokhai.gdt.gov.vn/xslt">
<xsl:include href="../../include/TKhaiHeader.xsl"/>
 <xsl:include href="../../include/TKhaiFooter.xsl"/>    
 <xsl:include href="../../common/common.xsl"/> 
	<xsl:template match="/">
	    <xsl:variable name="tkchinh" select='HSoThueDTu/HSoKhaiThue/CTieuTKhaiChinh' />
		<xsl:variable name="moTaBieuMau" select="'Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính'" />
		<xsl:variable name="ghiChuPL" select="'Kèm theo Tờ khai mẫu số 01/GTGT'"/>
	  <!-- Phụ lục 01-2/GTGT TT80 -->
		<xsl:if test="HSoThueDTu/HSoKhaiThue/PLuc/PLuc_01_2_GTGT"/>	
		<xsl:variable name="pl01_2" select='HSoThueDTu/HSoKhaiThue/PLuc/PLuc_01_2_GTGT' />
		<xsl:call-template name="tkhaiHeader_PL_01_2_GTGT_TT80">
			<xsl:with-param name="mauTKhai"   select="'01-2/GTGT'"/>
			<xsl:with-param name="moTaBieuMau"   select="$moTaBieuMau"/>
			<xsl:with-param name="tenPL"   select="'BẢNG PHÂN BỔ SỐ THUẾ GIÁ TRỊ GIA TĂNG PHẢI NỘP ĐỐI VỚI HOẠT ĐỘNG SẢN XUẤT THỦY ĐIỆN'"/>
			<xsl:with-param name="ghiChuPL"   select="' (Kèm theo Tờ khai mẫu số 01/GTGT)'"/>
		</xsl:call-template>

		<div class="ndungtkhai_div">
            <div class="content">
				<div  class="align-r"><i>Đơn vị tiền: Đồng Việt Nam</i></div>
                    <table class="tkhai_table">
                        <tr>
							<td class="align-c" rowspan="2"><b>STT</b></td>
							<td class="align-c" rowspan="2"><b>Chỉ tiêu</b></td>
							<td class="align-c" rowspan="2"><b>Mã số thuế/Mã địa điểm kinh doanh</b></td>
							<td class="align-c" colspan="2"><b>Địa bàn hoạt động sản suất, kinh doanh</b></td>
							<td class="align-c" rowspan="2"><b>Cơ quan thuế quản lý địa bàn nhận phân bổ</b></td>
							<td class="align-c" rowspan="2"><b>Số thuế GTGT phải nộp của nhà máy thủy điện</b></td>
							<td class="align-c" rowspan="2"><b>Tỷ lệ phân bổ (%)</b></td>
							<td class="align-c" rowspan="2"><b>Số thuế phải nộp</b></td>
						</tr>
						<tr>
							<td class="align-c"><b>Huyện</b></td>
							<td class="align-c"><b>Tỉnh</b></td>
						</tr>
						<tr>
							<td class="align-c"><b>[04]</b></td>
							<td class="align-c"><b>[05]</b></td>
							<td class="align-c"><b>[06]</b></td>
							<td class="align-c"><b>[07]</b></td>
							<td class="align-c"><b>[08]</b></td>
							<td class="align-c"><b>[09]</b></td>
							<td class="align-c"><b>[10]</b></td>
							<td class="align-c"><b>[11]</b></td>
							<td class="align-c"><b>[12]=[11]x[10]</b></td>
						</tr>
						<xsl:for-each select="$pl01_2/TenNhaMay">
							<xsl:variable name="currentRows" select="position()"/>
								<tr>
									<td class="align-l"><xsl:value-of select="$currentRows"/>.</td>
									<td class="align-l"><xsl:value-of select="ten_nhaMay"/></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td class="align-r"><b><xsl:value-of select="ihtkk:formatNumber($pl01_2/TenNhaMay/ct10_a)"/></b></td>
									<td class="align-r"><b><xsl:value-of select="ihtkk:formatNumber($pl01_2/TenNhaMay/ct11_a)"/></b></td>
									<td class="align-r"><b><xsl:value-of select="ihtkk:formatNumber($pl01_2/TenNhaMay/ct12_a)"/></b></td>
								</tr>
	          				<xsl:for-each select="DiaBanPhanBo">
								<xsl:variable name="currentRows1" select='position()'/>
								<tr>
									<td class="align-c"><xsl:value-of select="$currentRows1"/></td>
									<td class="align-l"><xsl:value-of select="ct05"/></td>
									<td class="align-l"><xsl:value-of select="ct06"/></td>
									<td class="align-l"><xsl:value-of select="ct07_huyen_ten"/></td>
									<td class="align-l"><xsl:value-of select="ct08_tinh_ten"/></td>
									<td class="align-l"><xsl:value-of select="ct09_cqt_ten"/></td>
									<td class="align-r"><xsl:value-of select="ihtkk:formatNumber(ct10)"/></td>
									<td class="align-r"><xsl:value-of select="ihtkk:formatNumber(ct11)"/></td>
									<td class="align-r"><xsl:value-of select="ihtkk:formatNumber(ct12)"/></td>				
								</tr>
							</xsl:for-each>	       				 
						</xsl:for-each>						 											
							<tr>
							    <td></td>
							    <td class="align-l" colspan="5"><b>Cộng ([13]=∑[10]; [14]=∑[12])</b></td>
							    <td class="align-r"><b><xsl:value-of select="ihtkk:formatNumber($pl01_2/ct13)"/></b></td>
								<td class="align-c">\</td>
								<td class="align-r"><b><xsl:value-of select="ihtkk:formatNumber($pl01_2/ct14)"/></b></td>
  							</tr>
					</table>
			</div>

		</div>
		<table style="page-break-inside: avoid;width:100%" >
			<tr>
				<td>		  
					<div class="ghichu">   
						<xsl:call-template name="tkhaiFooter_TT80"/>
					</div>
					<div id="sigDiv"></div>
				</td>
			</tr>
		</table>
	</xsl:template>		
</xsl:stylesheet>

